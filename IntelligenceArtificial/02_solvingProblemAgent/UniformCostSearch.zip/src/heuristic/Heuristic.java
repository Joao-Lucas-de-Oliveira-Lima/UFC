package src.heuristic;

import src.graph.State;
import java.util.ArrayList;

public interface Heuristic {
    
}
